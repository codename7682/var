$(document).ready(function(){
    
    var word = $("#word").text();
    var len = word.length;
    var letter = new Array(len);
    
    for(i=0; i<len; i++){
        letter[i] = word.charAt(i);
    }
    
    $("#word").empty();
    
    
    var a = -1;
    function adding(){
        a++;
        $("#word").append(letter[a]);
        if(a <= len){
            setTimeout(adding, 100);
        }
    }
    adding();
    
});















